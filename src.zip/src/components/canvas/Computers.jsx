import React from 'react'

const Computers = () => {
  return (
    <div>Computers</div>
  )
}

export default Computers