import React, {useEffect, useState} from 'react';
import { Link } from 'react-router-dom';

import { styles } from '../styles';
import { navLinks } from '../constants';
import { logo, menu, close } from '../assets';
const Navbar = () => {
  const [active, setActive] =useState("")
  const [toggle, setToggle] =useState("false")


  return (
    <nav className={'${styles.paddingx} w-full flex items-center py-5 fixed top-0 z-20 bg-primary'}>
      <div className="w-full flex justify between items-center max-w-7xl mx-auto ">

        <Link to="/" className="flex items-center gap-2" onClick={() => {setActive(""); windows.scrollTo(0,0);

        }}>
          <img src="logo.svg" alt="logo" className= "w-9 h-9 object-contain"/>
          <p className='text-white text-[18px] font-bold cursor-pointer'>Miracle Kwasi Gamor<span className='sm:block hidden'>| FrontEnd Developer </span></p>

        </Link>
        <ul className="list-none hidden sm:flex flex-row gap-10">
          {navLinks.map((link) => (
            <li key={link.id} 
            className={'${ active === link.title ? "text-blue": "text-secondary"} hover:text-blue text -[18px] font-medium cursor-pointer'}onclick={() => setActive(link.id)}>
              <a href={"#${link.id}"}>{link.title}</a>
            </li>
          ))}
        </ul>
        <div className='sm:hidden flex flex-1 
        justify-end items-center'>
          <img src="menu" alt="menu" className='w-[28px] h-[] object-contain cursor-pointer 'onclick={() => setToggle(!toggle)}/>


        </div>

      </div>
    </nav>
  )
}

export default Navbar